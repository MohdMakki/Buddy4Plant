#include <iostream>

struct Node {
    int data;
    Node* next;
};

class LinkedList {
private:
    Node* head;
public:
    LinkedList() : head(nullptr) {}

    // Function to add a new node at the end of the linked list
    void append(int data) {
        Node* newNode = new Node;
        newNode->data = data;
        newNode->next = nullptr;

        if (head == nullptr) {
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next != nullptr) {
                temp = temp->next;
            }
            temp->next = newNode;
        }
    }

    // Function to get a pointer to the last element of the linked list
    Node* getLastElement() {
        if (head == nullptr) {
            return nullptr; // Empty list
        }

        Node* temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        return temp;
    }
};

int main() {
    LinkedList list;
    list.append(1);
    list.append(2);
    list.append(3);

    Node* lastElement = list.getLastElement();
    if (lastElement != nullptr) {
        std::cout << "The last element of the linked list is: " << lastElement->data << std::endl;
    } else {
        std::cout << "The linked list is empty." << std::endl;
    }

    return 0;
}
